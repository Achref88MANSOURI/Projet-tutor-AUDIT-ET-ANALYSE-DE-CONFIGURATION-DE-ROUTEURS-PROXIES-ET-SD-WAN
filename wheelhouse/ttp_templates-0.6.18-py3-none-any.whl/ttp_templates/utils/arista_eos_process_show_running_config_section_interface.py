"""
Normalize Arista EOS interface configuration parsed by TTP into a
standardized list of dictionaries suitable for Netbox imports.

Transforms the parsed result of ``show running-config section interface``
into a flat list where each interface dictionary contains a fixed set of
keys. Missing or unknown values are returned as ``None`` (except
``description`` which is returned as an empty string when unset, and
``tagged_vlans`` which is an empty list when none).

Used by:
- ttp_templates/platform/arista_eos_show_running_config_section_interface.txt

Produced with Copilot Assistance.
"""

from ipaddress import IPv4Address, IPv4Interface
from typing import Any, Dict, List, Optional

from .models import InterfaceConfigRecord

# converts interface speed config to kbit/s
speed_map = {
    "100full": 10000,
    "100g": 100000000,
    "100g-1": 100000000,
    "100g-2": 100000000,
    "100g-4": 100000000,
    "100half": 10000,
    "10full": 1000,
    "10g": 10000000,
    "10half": 1000,
    "1g": 1000000,
    "200g": 200000000,
    "200g-2": 200000000,
    "200g-4": 200000000,
    "25g": 25000000,
    "400g": 400000000,
    "400g-4": 400000000,
    "400g-8": 400000000,
    "40g": 40000000,
    "50g": 50000000,
    "50g-1": 50000000,
    "50g-2": 50000000,
}


def transform_interfaces_config(payload: list) -> list[dict[str, Any]]:
    """
    Transform TTP parse payload for Arista interface blocks into a
    normalized list of interface dictionaries.

    Args:
        payload: TTP macro payload.

    Returns:
        Normilized list of dictionaries with the fixed set of keys described in the
        template documentation.
    """
    if not payload:
        return []

    interfaces: list[dict[str, Any]] = []

    for item in payload:
        if not isinstance(item, dict):
            continue

        # Top-level container with "interfaces": { <name>: {...} }
        if "interfaces" in item and isinstance(item["interfaces"], dict):
            for nm, data in item["interfaces"].items():
                d = dict(data) if isinstance(data, dict) else {}
                d["name"] = nm
                interfaces.append(d)

        # Items where keys are interface names mapping to dicts
        elif any(isinstance(v, dict) for v in item.values()) and not item.get("name"):
            for nm, data in item.items():
                if isinstance(data, dict):
                    d = dict(data)
                    d["name"] = nm
                    interfaces.append(d)

        # Individual records with a "name" key
        elif item.get("name"):
            interfaces.append(dict(item))

    normalized_interfaces: List[Dict[str, Any]] = []

    for iface in interfaces:
        name = iface.get("name")
        name_lower = str(name).lower() if name is not None else ""

        # Determine type according to rules in the template doc
        if "vlan" in name_lower:
            interface_type = "bridge"
        elif "port-channel" in name_lower:
            interface_type = "lag"
        elif any(k in name_lower for k in [".", "loopback"]):
            interface_type = "virtual"
        else:
            interface_type = "other"

        # `enabled` is produced by the template as a boolean; default to
        # True when the key is absent.
        enabled = iface.get("enabled", True)

        lag_id = iface.get("lag_id")
        lag_type = iface.get("lag_type") or None
        lacp_mode = iface.get("lacp_mode") or None
        lag = None
        if lag_id and interface_type != "lag":
            lag = f"Port-Channel{lag_id}"
        mtu = iface.get("mtu")
        description = iface.get("description") or ""
        mode = iface.get("mode") or None

        # calculate untagged vlan for SVIs
        untagged = None
        if iface.get("untagged_vlan"):
            untagged = iface["untagged_vlan"]
        elif "vlan" in name_lower:
            untagged = int(name_lower.replace("vlan", ""))
            mode = "access"

        parent: Optional[str] = None
        if name and "." in str(name):
            parent = str(name).split(".", 1)[0]
            interface_type = "virtual"

        # Convert template-provided tagged VLAN list elements to ints
        raw_tagged = iface.get("tagged_vlans")
        tagged_vlans: List[int] = []
        if isinstance(raw_tagged, list):
            for v in raw_tagged:
                try:
                    tagged_vlans.append(int(v))
                except (TypeError, ValueError):
                    continue
            tagged_vlans = sorted(set(tagged_vlans))

        if iface.get("allowed_vlan_all"):
            mode = "tagged-all"
            tagged_vlans = []

        dot1q = iface.get("dot1q")
        if dot1q is not None and dot1q not in tagged_vlans:
            tagged_vlans.append(dot1q)
            tagged_vlans = sorted(set(tagged_vlans))
            mode = mode or "tagged"

        vrf = iface.get("vrf") or None

        speed = iface.get("speed")
        duplex = str(iface.get("duplex") or "").strip().lower() or None

        ipv4_addresses = [
            {
                "ip": f"{i['ip']}/{i['mask']}",
                "ip_address_role": (
                    "loopback"
                    if "loopback" in name_lower
                    else i.get("ip_address_role", "")
                ),
            }
            for i in iface.get("ipv4_addresses", [])
            if isinstance(i, dict) and i.get("ip") and i.get("mask")
        ]
        vip = iface.get("vip")
        if vip:
            matching_subnets = [
                IPv4Interface(address["ip"]).network
                for address in ipv4_addresses
                if IPv4Address(vip) in IPv4Interface(address["ip"]).network
            ]
            if matching_subnets:
                prefix = max(matching_subnets, key=lambda subnet: subnet.prefixlen).prefixlen
                ipv4_addresses.append(
                    {"ip": f"{vip}/{prefix}", "ip_address_role": "vip"}
                )

        ipv6_addresses = [
            {
                "ip": f"{i['ip'].lower()}/{i['mask']}",
                "ip_address_role": (
                    "loopback"
                    if "loopback" in name_lower
                    else i.get("ip_address_role", "")
                ),
            }
            for i in iface.get("ipv6_addresses", [])
            if isinstance(i, dict) and i.get("ip") and i.get("mask")
        ]

        record: Dict[str, Any] = {
            "name": name,
            "type": interface_type,
            "enabled": enabled,
            "parent": parent,
            "lag": lag,
            "lag_id": lag_id,
            "lag_type": lag_type,
            "lacp_mode": lacp_mode,
            "mtu": mtu,
            "mac_address": iface.get("mac_address"),
            "speed": speed_map.get(speed, None),
            "duplex": duplex,
            "description": description,
            "mode": mode,
            "untagged_vlan": untagged,
            "tagged_vlans": tagged_vlans,
            "ipv4_addresses": ipv4_addresses,
            "ipv6_addresses": ipv6_addresses,
            "qinq_svlan": iface.get("qinq_svlan"),
            "vrf": vrf,
        }

        # run pydantic validation
        record = InterfaceConfigRecord(**record).model_dump()

        normalized_interfaces.append(record)

    return normalized_interfaces
