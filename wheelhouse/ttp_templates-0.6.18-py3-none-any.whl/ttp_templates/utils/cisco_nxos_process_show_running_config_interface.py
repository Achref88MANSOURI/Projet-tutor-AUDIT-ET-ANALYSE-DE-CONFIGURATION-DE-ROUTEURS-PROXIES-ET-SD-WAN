"""
Normalize Cisco NX-OS interface configuration parsed by TTP into a
standardized list of dictionaries suitable for Netbox imports.

Transforms the parsed result of ``show running-config interface`` into a
flat list where each interface dictionary contains a fixed set of keys.
Missing or unknown values are returned as ``None`` (except ``description``
which is returned as an empty string when unset, and ``tagged_vlans`` which
is an empty list when none).

Used by:
- ttp_templates/platform/cisco_nxos_show_running_config_interface.txt
"""

import ipaddress
from typing import Any

from .models import InterfaceConfigRecord


def _mask_to_prefix_len(mask: str) -> int:
    """Convert a dotted IPv4 mask or numeric mask to a prefix length."""
    if "." in mask:
        return ipaddress.IPv4Network(f"0.0.0.0/{mask}", strict=False).prefixlen
    return int(mask)


def _flatten_vlan_values(values: Any) -> list[int]:
    """Flatten TTP VLAN captures into a sorted list of unique integers."""
    if values is None:
        return []

    raw_values = values if isinstance(values, list) else [values]
    vlans: list[int] = []
    for item in raw_values:
        if isinstance(item, list):
            vlans.extend(_flatten_vlan_values(item))
            continue

        for value in str(item).split(","):
            try:
                vlans.append(int(value))
            except (TypeError, ValueError):
                continue

    return sorted(set(vlans))


def _normalize_ipv4_addresses(addresses: Any, is_loopback: bool) -> list[dict[str, Any]]:
    """Return normalized IPv4 address dictionaries with NetBox roles."""
    if not isinstance(addresses, list):
        return []

    normalized: list[dict[str, Any]] = []
    for addr in addresses:
        if not isinstance(addr, dict) or not addr.get("ip") or not addr.get("mask"):
            continue

        try:
            mask = _mask_to_prefix_len(str(addr["mask"]))
        except (TypeError, ValueError):
            mask = addr["mask"]
        normalized.append(
            {
                "ip": f"{addr['ip']}/{mask}",
                "ip_address_role": (
                    "loopback"
                    if is_loopback
                    else addr.get("ip_address_role", "")
                ),
            }
        )

    return normalized


def transform_interfaces_config(payload: list) -> list[dict[str, Any]]:
    """
    Transform TTP parse payload for Cisco NX-OS interface blocks into a
    normalized list of interface dictionaries.

    Args:
        payload: TTP macro payload.

    Returns:
        Normalized list of dictionaries with the fixed set of keys described
        in the template documentation.
    """
    if not payload:
        return []

    normalized_interfaces: list[dict[str, Any]] = []

    for iface in payload:
        if not isinstance(iface, dict) or not iface.get("name"):
            continue

        name = iface["name"]
        name_lower = name.lower()

        if "vlan" in name_lower:
            interface_type = "bridge"
        elif "port-channel" in name_lower:
            interface_type = "lag"
        elif any(marker in name_lower for marker in [".", "loopback", "tunnel", "nve"]):
            interface_type = "virtual"
        else:
            interface_type = "other"

        parent = name.split(".", 1)[0] if "." in name else None
        if parent:
            interface_type = "virtual"

        lag_id = iface.get("lag_id")
        lag_type = iface.get("lag_type")
        lag = None
        if lag_id and interface_type != "lag":
            lag = f"Port-channel{lag_id}"

        mode = iface.get("mode")
        untagged_vlan = iface.get("untagged_vlan")
        tagged_vlans = _flatten_vlan_values(iface.get("tagged_vlans"))
        if iface.get("allowed_vlan_all"):
            mode = "tagged-all"
            tagged_vlans = []

        dot1q = iface.get("dot1q")
        if dot1q is not None and dot1q not in tagged_vlans:
            tagged_vlans.append(dot1q)
            tagged_vlans = sorted(set(tagged_vlans))
            mode = mode or "tagged"

        if interface_type == "bridge":
            try:
                untagged_vlan = int(name_lower.replace("vlan", ""))
                mode = "access"
            except ValueError:
                pass
        elif untagged_vlan is not None and mode is None:
            mode = "access"
        elif tagged_vlans and mode is None:
            mode = "tagged"

        speed = iface.get("speed")
        if speed is not None:
            speed = speed * 1000
        duplex = str(iface.get("duplex") or "").strip().lower() or None

        record: dict[str, Any] = {
            "name": name,
            "type": interface_type,
            "enabled": iface.get("enabled", True),
            "parent": parent,
            "lag": lag,
            "lag_id": lag_id,
            "lag_type": lag_type,
            "lacp_mode": iface.get("lacp_mode"),
            "mtu": iface.get("mtu"),
            "mac_address": iface.get("mac_address"),
            "speed": speed,
            "duplex": duplex,
            "description": iface.get("description") or "",
            "mode": mode,
            "untagged_vlan": untagged_vlan,
            "tagged_vlans": tagged_vlans,
            "ipv4_addresses": _normalize_ipv4_addresses(
                iface.get("ipv4_addresses"), "loopback" in name_lower
            ),
            "ipv6_addresses": [
                {
                    "ip": f"{addr['ip'].lower()}/{addr['mask']}",
                    "ip_address_role": (
                        "loopback"
                        if "loopback" in name_lower
                        else addr.get("ip_address_role", "")
                    ),
                }
                for addr in iface.get("ipv6_addresses", [])
                if isinstance(addr, dict) and addr.get("ip") and addr.get("mask")
            ],
            "qinq_svlan": None,
            "vrf": iface.get("vrf"),
        }

        if iface.get("is_anycast_gateway"):
            for address in record["ipv4_addresses"] + record["ipv6_addresses"]:
                if address["ip_address_role"] != "secondary":
                    address["ip_address_role"] = "anycast"

        record = InterfaceConfigRecord(**record).model_dump()
        normalized_interfaces.append(record)

    return normalized_interfaces
