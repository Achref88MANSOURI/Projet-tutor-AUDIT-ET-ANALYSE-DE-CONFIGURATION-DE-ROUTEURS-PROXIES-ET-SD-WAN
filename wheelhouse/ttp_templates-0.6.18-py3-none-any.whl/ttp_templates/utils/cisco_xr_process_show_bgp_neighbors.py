"""
Normalize Cisco IOS-XR BGP neighbors text output to a standardized format.

Transforms TTP-parsed output from 'show bgp neighbors' into a normalized
list of dictionaries suitable for further processing and integrations.

Used by:
- ttp_templates/platform/cisco_xr_show_bgp_neighbors.txt
"""

import re

from ttp_templates.utils.models import BgpNeighborRecord

# XR display name -> IANA AFI/SAFI name
_AFI_TO_IANA = {
    "IPv4 Unicast": "ipv4_unicast",
    "IPv6 Unicast": "ipv6_unicast",
    "IPv4 Multicast": "ipv4_multicast",
    "IPv6 Multicast": "ipv6_multicast",
    "VPNv4 Unicast": "ipv4_mpls_vpn",
    "VPNv6 Unicast": "ipv6_mpls_vpn",
    "IPv4 Labeled-unicast": "ipv4_labeled_unicast",
    "IPv6 Labeled-unicast": "ipv6_labeled_unicast",
    "L2VPN EVPN": "l2vpn_evpn",
    "L2VPN Vpls": "l2vpn_vpls",
    "IPv4 MDT": "ipv4_mdt",
    "IPv4 Flowspec": "ipv4_flow_spec",
    "IPv6 Flowspec": "ipv6_flow_spec",
    "IPv4 SR policy": "ipv4_sr_te",
    "IPv6 SR policy": "ipv6_sr_te",
    "Link-state Link-state": "link_state",
}

_BGP_STATES = {"idle", "connect", "active", "opensent", "openconfirm", "established"}
_LINK_TYPES = {"external", "internal"}
_CONFIG_AFI_TO_IANA = {
    "vpnv4_unicast": "ipv4_mpls_vpn",
    "vpnv6_unicast": "ipv6_mpls_vpn",
    "ipv4_flowspec": "ipv4_flow_spec",
    "ipv6_flowspec": "ipv6_flow_spec",
}


def _uptime_to_seconds(uptime):
    if not uptime:
        return None
    m = re.match(r"^(\d+):(\d+):(\d+)$", uptime)
    if m:
        return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3))
    m = re.match(r"(?:(\d+)w)?(?:(\d+)d)?(?:(\d+)h)?", uptime)
    if m:
        return (
            int(m.group(1) or 0) * 604800
            + int(m.group(2) or 0) * 86400
            + int(m.group(3) or 0) * 3600
        )
    return None


def transform_bgp_neighbors(data):
    if isinstance(data, dict):
        payload = data
    elif isinstance(data, list) and data and isinstance(data[0], dict):
        payload = data[0]
    else:
        return []
    neighbors = payload.get("neighbors") or []

    # Index formal config by peer group and by (VRF, neighbor address).
    peer_groups = {}
    for item in payload.get("peer_group_config") or []:
        group = peer_groups.setdefault(item["peer_group"], {"families": {}})
        if "afi" in item:
            family = group["families"].setdefault((item["afi"], item["safi"]), {})
            if "policy" in item:
                family[item["direction"]] = item["policy"]
        else:
            group.update({name: value for name, value in item.items() if name not in ("bgp_as", "peer_group")})

    neighbor_configs = {}
    for item in payload.get("neighbor_config") or []:
        config = neighbor_configs.setdefault((item.get("vrf"), item["remote_address"]), {"families": {}})
        if "afi" in item:
            family = config["families"].setdefault((item["afi"], item["safi"]), {})
            if "policy" in item:
                family[item["direction"]] = item["policy"]
        else:
            config.update({name: value for name, value in item.items() if name not in ("bgp_as", "vrf", "remote_address")})

    result = []
    for n in neighbors:
        raw_state = n.get("bgp_state") or ""
        state_token = raw_state.split(",")[0].strip().lower()
        state = state_token if state_token in _BGP_STATES else None

        uptime_match = re.search(r"up for\s+(\S+)", raw_state)
        uptime = _uptime_to_seconds(uptime_match.group(1) if uptime_match else None)

        peering_raw = (n.get("peering_type") or "").lower()
        remote_address = n.get("remote_address")

        afi_list = []
        per_afi = {}
        operational_import_policies = []
        operational_export_policies = []
        local_address = n.get("local_address")
        vrf_raw = n.get("vrf", "default")
        vrf = None if vrf_raw in ("default", "master") else vrf_raw
        config = neighbor_configs.get((vrf, remote_address), {})
        group = peer_groups.get(config.get("peer_group"), {})
        # Direct neighbor settings take precedence over inherited group settings.
        effective = {**group, **config}

        for af in n.get("address_families") or []:
            afi_raw = af.get("afi_name") or ""
            afi_key = (
                _AFI_TO_IANA.get(afi_raw, afi_raw.lower().replace(" ", "_"))
                if afi_raw
                else None
            )
            if afi_key and afi_key not in afi_list:
                afi_list.append(afi_key)
            if afi_key:
                if af.get("accepted_prefixes") is not None:
                    per_afi[f"{afi_key}_prefixes_received"] = int(af["accepted_prefixes"])
                if af.get("prefixes_sent") is not None:
                    per_afi[f"{afi_key}_prefixes_sent"] = int(af["prefixes_sent"])
            for key, policies in (("import_policy", operational_import_policies), ("export_policy", operational_export_policies)):
                policy = (af.get(key) or "").strip()
                if policy and policy not in policies:
                    policies.append(policy)
            if local_address is None:
                local_address = af.get("local_address")

        # Collect policies across AFIs, keeping group and neighbor lists separate.
        group_policies = {"in": [], "out": []}
        neighbor_policies = {"in": [], "out": []}
        for family_key in dict.fromkeys([*group.get("families", {}), *config.get("families", {})]):
            afi_key = "_".join(family_key).replace("-", "_")
            afi_key = _CONFIG_AFI_TO_IANA.get(afi_key, afi_key)
            if afi_key not in afi_list:
                afi_list.append(afi_key)
            for families, policies in (
                (group.get("families", {}), group_policies),
                (config.get("families", {}), neighbor_policies),
            ):
                for direction in ("in", "out"):
                    policy = families.get(family_key, {}).get(direction)
                    if policy and policy not in policies[direction]:
                        policies[direction].append(policy)

        # A direct policy list replaces the group list for that direction.
        import_policies = neighbor_policies["in"] or group_policies["in"]
        export_policies = neighbor_policies["out"] or group_policies["out"]

        record = {
            "name": f"{vrf or 'default'}_{remote_address}",
            "vrf": vrf,
            "state": state,
            "peering_type": peering_raw if peering_raw in _LINK_TYPES else None,
            "remote_address": remote_address,
            "remote_as": int(effective.get("remote_as", n.get("remote_as"))),
            "local_address": local_address,
            "local_as": int(effective.get("local_as", n.get("local_as"))),
            "local_interface": effective.get("update_source"),
            "router_id": n.get("router_id"),
            "peer_group": effective.get("peer_group"),
            "description": effective.get("description", n.get("description")),
            "hold_time": int(n["hold_time"]) if n.get("hold_time") else None,
            "keepalive": int(n["keepalive"]) if n.get("keepalive") else None,
            "uptime_seconds": uptime,
            "max_ttl": None,
            "afi": afi_list,
            "import_policies": import_policies or operational_import_policies,
            "export_policies": export_policies or operational_export_policies,
            "prefix_list_in": None,
            "prefix_list_out": None,
            **per_afi,
        }
        result.append(BgpNeighborRecord(**record).model_dump(exclude_unset=True))

    return result
