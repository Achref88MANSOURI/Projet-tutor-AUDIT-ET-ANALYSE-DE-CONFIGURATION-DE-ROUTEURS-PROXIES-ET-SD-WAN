"""
Normalize Cisco IOS VLAN configuration parsed by TTP.

Transforms VLAN and interface sections from IOS running configuration into a
flat list of VLAN dictionaries suitable for getter-style consumption.

Used by:
- ttp_templates/platform/cisco_ios_show_running_config_pipe_section_vlan.txt
"""

from typing import Any, Dict, List

from .models import VlanRecord


def _expand_vlan_ids(value: Any) -> List[int]:
    """Expand VLAN strings such as ``2,100-105`` into integer IDs."""
    vlans: List[int] = []
    for part in str(value).split(","):
        if "-" in part:
            start, end = part.split("-", 1)
            vlans.extend(range(int(start), int(end) + 1))
        else:
            vlans.append(int(part))
    return vlans


def transform_vlans_config(payload: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Convert parsed Cisco IOS VLAN stanzas into normalized VLAN records.

    Args:
        payload: TTP macro payload.

    Returns:
        List of normalized VLAN dictionaries including interface membership.
    """
    if not payload:
        return []

    records: Dict[int, Dict[str, Any]] = {}
    for vlan in payload.get("vlans", []):
        for vid in _expand_vlan_ids(vlan.get("vid")):
            if not 1 <= vid <= 4095:
                continue
            record = records.setdefault(
                vid,
                {
                    "vid": vid,
                    "name": vlan.get("name") or f"VLAN{vid}",
                    "description": vlan.get("description") or None,
                    "tagged_interfaces": [],
                    "untagged_interfaces": [],
                },
            )
            if vlan.get("name"):
                record["name"] = vlan["name"]
            if vlan.get("description"):
                record["description"] = vlan["description"]

    for interface in payload.get("interfaces", []):
        name = interface["name"]
        memberships = []
        untagged_vid = interface.get("untagged_vlan")
        name_lower = name.lower()
        for prefix in ("vlan", "bvi"):
            suffix = name_lower.removeprefix(prefix)
            if suffix != name_lower and suffix.isdigit():
                untagged_vid = int(suffix)

        if untagged_vid is not None:
            memberships.append((int(untagged_vid), "untagged_interfaces"))

        tagged_values = interface.get("tagged_vlans") or []
        if not isinstance(tagged_values, list):
            tagged_values = [tagged_values]
        for value in tagged_values:
            memberships.append((int(value), "tagged_interfaces"))

        for vid, membership_type in memberships:
            if not 1 <= vid <= 4095:
                continue
            record = records.setdefault(
                vid,
                {
                    "vid": vid,
                    "name": f"VLAN{vid}",
                    "description": None,
                    "tagged_interfaces": [],
                    "untagged_interfaces": [],
                },
            )
            if name not in record[membership_type]:
                record[membership_type].append(name)

    return [VlanRecord(**record).model_dump() for record in records.values()]
